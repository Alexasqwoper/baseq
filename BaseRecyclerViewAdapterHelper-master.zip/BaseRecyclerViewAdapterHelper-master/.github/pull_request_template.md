Thank you for contributing to BaseRecyclerViewAdapterHelper. Before pressing the "Create Pull Request" button, please consider the following points:

  - [1] Please give a description about what and why you are contributing, even if it's trivial.

  - [2] Please include the issue list number(s) or other PR numbers in the description if you are contributing in response to those.

  - [3] Please include a reasonable set of demo tests if you contribute new code or change an existing one. please make sure you have demo for working correctly.
